

create database keys

use keys

CREATE TABLE Persons (
    ID int NOT NULL PRIMARY KEY,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255),
    Age int
);

select * from Persons


insert into Persons values(101,'azar','mohamed',23)

insert into Persons values(101,'azar1','mohamed1',24)



CREATE TABLE Orders (
    OrderID int NOT NULL PRIMARY KEY,
    OrderNumber int NOT NULL,
    PersonID int FOREIGN KEY REFERENCES Persons(ID)
);

select * from Orders

insert into Orders values(201,1234,101)



create table Sample(empid int,empname varchar(50),salary int,age int)

insert into Sample values(101,'emp1',20000,23)
insert into Sample values(102,'emp2',10000,24)

insert into Sample values(103,'emp3',20000,23)

select * from Sample

alter table Sample ADD email varchar(100)

update Sample set email='admin@gmail.com' where salary=20000


alter table Sample drop column email


Oracle10G

ALTER TABLE table_name
MODIFY COLUMN column_name datatype;


Above10G

ALTER TABLE table_name
MODIFY column_name datatype;