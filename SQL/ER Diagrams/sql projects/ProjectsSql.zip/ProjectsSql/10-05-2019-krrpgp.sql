SELECT EmployeeID, Title, LoginID FROM 
	HumanResources.Employee WHERE Title IN ('Recruiter', 'Stocker')
	
	SELECT EmployeeID, Title, LoginID FROM 
	HumanResources.Employee WHERE Title not IN ('Recruiter', 'Stocker')
	
	select * from HumanResources.Employee
	
select title from HumanResources.Employee where Title LIKE 'P%'

select title from HumanResources.Employee where Title LIKE '%n'

select title from HumanResources.Employee where Title LIKE '%n%'

select title from HumanResources.Employee where Title LIKE '_a%'

select title from HumanResources.Employee where Title LIKE '_a%'
	
select EmployeeID from HumanResources.Employee order by EmployeeID DESC
	
	
update HumanResources.Employee set MaritalStatus='S' where EmployeeID=1	

select MIN(ManagerID) from HumanResources.Employee
	
select MAX(ManagerID) from HumanResources.Employee	

select SUM(ManagerID) from HumanResources.Employee	

select COUNT(ManagerID) from HumanResources.Employee
	
select AVG(ManagerID) from HumanResources.Employee
	