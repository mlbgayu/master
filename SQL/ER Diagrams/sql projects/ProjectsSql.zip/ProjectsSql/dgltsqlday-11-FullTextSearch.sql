use AdventureWorks


<!--The full-text catalog may have multiple full-text indexes. You can create a full-text catalog using the following command:-->

CREATE FULLTEXT CATALOG Cat1 AS DEFAULT

CREATE UNIQUE INDEX Ix_Desc ON 
Production.ProductDescription 
(ProductDescriptionID)

CREATE FULLTEXT INDEX ON 
Production.ProductDescription (Description)  
KEY INDEX Ix_Desc

CREATE FULLTEXT INDEX ON 
Production.ProductDescription (Description)
KEY INDEX 
PK_ProductDescription_ProductDescriptionID
WITH CHANGE_TRACKING OFF, NO POPULATION

ALTER FULLTEXT INDEX ON 
Production.ProductDescription 
START FULL POPULATION


SELECT Description FROM 
Production.ProductDescription 	
WHERE FREETEXT (Description, 'race winners')

SELECT f.RANK,ProductDescriptionID,Description
From Production.ProductDescription d
INNER JOIN 
FREETEXTTABLE(Production.ProductDescription, 
Description,'race winners')f
ON d.ProductDescriptionID = f.[KEY]
ORDER BY f.RANK DESC

SELECT Description 
FROM Production.ProductDescription
WHERE CONTAINS (Description, 'ride NEAR bike')

SELECT f.RANK,ProductDescriptionID,Description
From Production.ProductDescription d
INNER JOIN 
CONTAINSTABLE(Production.ProductDescription, 
Description,'Entry ')f
ON d.ProductDescriptionID = f.[KEY]
ORDER BY f.RANK DESC


