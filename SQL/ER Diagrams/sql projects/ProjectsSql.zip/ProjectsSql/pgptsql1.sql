create database pgp
use pgp

create table emp1(empid varchar(50),ename varchar(50),salary varchar(50),address varchar(50))

select empid,ename from emp1 where salary>=30000

insert into emp1 values(101,'azar',30000,'krr')

insert into emp1 values(102,'azar1',3000,'krr')

DROP DATABASE pgp

drop table emp1

select * from emp1

alter table emp1 add payment varchar(50)

alter table emp1 alter column payment varchar(20)


alter table emp1 drop column payment