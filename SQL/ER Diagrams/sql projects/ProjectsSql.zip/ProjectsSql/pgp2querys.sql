create database pgp2

use pgp2

create table emp1(uname varchar(50),email varchar(50),salary integer)


select uname,email from emp1


select * from emp1 where uname='admin'

insert into emp1 values('admin','admin@gmail.com',20000)


insert into emp1 values('admin1','admin1@gmail.com',2000)


insert into emp1 values('admin2','admin2@gmail.com',3000)