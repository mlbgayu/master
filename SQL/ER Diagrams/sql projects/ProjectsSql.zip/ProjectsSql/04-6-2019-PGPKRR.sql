set SHOWPLAN_ALL ON
use pgpthirdbatch
create table employees(empid integer,empname varchar(90),empage integer,empsalary integer)

insert into employees
values(1001,'ram',30,35000)


insert into employees
values(1002,'rajkumar',22,25000)

insert into employees
values(1003,'rajan',27,30000)

insert into employees
values(1004,'ramu',31,33000)

select * from employees


CREATE INDEX idx_empname
ON employees (empname);


select * from employees where empname='ramu'

