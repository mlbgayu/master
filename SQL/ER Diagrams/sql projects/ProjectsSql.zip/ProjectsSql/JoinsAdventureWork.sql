use AdventureWorks

select * from HumanResources.Employee

select * from HumanResources.Department

select HumanResources.Employee.LoginID,HumanResources.Department.Name

from HumanResources.Employee Inner Join 

HumanResources.Department on 

HumanResources.Employee.EmployeeID=HumanResources.Department.DepartmentID



select HumanResources.Employee.LoginID,HumanResources.Department.Name

from HumanResources.Employee Left join

HumanResources.Department on 

HumanResources.Employee.EmployeeID=HumanResources.Department.DepartmentID


select HumanResources.Employee.LoginID,HumanResources.Department.Name

from HumanResources.Employee right join

HumanResources.Department on 

HumanResources.Employee.EmployeeID=HumanResources.Department.DepartmentID

select HumanResources.Employee.LoginID,HumanResources.Department.Name

from HumanResources.Employee full join

HumanResources.Department on 

HumanResources.Employee.EmployeeID=HumanResources.Department.DepartmentID


select * from HumanResources.Employee 

select COUNT(HumanResources.Employee.EmployeeID)as demo,Title from HumanResources.Employee group by Title
