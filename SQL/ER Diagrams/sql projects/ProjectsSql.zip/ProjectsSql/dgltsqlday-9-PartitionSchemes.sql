use AdventureWorks

CREATE PARTITION FUNCTION SalesDate ( datetime )
AS RANGE RIGHT FOR VALUES ('2004-01-01', '2007-01-01', '2010-01-01')

CREATE PARTITION SCHEME SalesDate
AS PARTITION SalesDate
TO (FG1, FG2, FG3, FG4)

CREATE TABLE Sales
( 
SalesID int,
OrderID int,
ProductID int,
Quantity int,
TotalPrice money,
SalesDate datetime
)ON SalesDate(SalesDate)

select * from Sales

insert into Sales values(1001,2001,3001,20,10000,'2004-01-01')

USE [AdventureWorks]
GO

/****** Object:  PartitionScheme [SalesDate]    Script Date: 01/08/2019 14:29:56 ******/
CREATE PARTITION SCHEME [SalesDate] AS PARTITION [SalesDate] TO ([FG1], [FG2], [FG3], [FG4])
GO


select * from Sales where SalesDate='2004-01-01'

