
create database employees

use employees

create table emp1(empid varchar(50),empname varchar(50),salary varchar(50),address varchar(50))


select * from emp1

insert into emp1 values(101,'azar',20000,'krr')

insert into emp1 values(102,'mohan',10000,'ppt')
insert into emp1 values(103,'raja',20000,'krr')
insert into emp1 values(104,'sheik',10000,'ppt')
insert into emp1 values(105,'sheik',10000,'')


select * from emp1

select empid,salary from emp1



/*where clause*/


 -->where clause is an used for check condition
 
 /*Operators in The WHERE Clause
 
 
Operator	Description
=	Equal
<>	Not equal. Note: In some versions of SQL this operator may be written as !=
>	Greater than
<	Less than
>=	Greater than or equal
<=	Less than or equal
BETWEEN	Between an inclusive range
LIKE	Search for a pattern
IN	To specify multiple possible values for a column*/
 
 
 
 
select * from emp1 where  salary>=20000
 
 
 
 /*SQL SELECT DISTINCT Statement 
 The SELECT DISTINCT statement is used to return only distinct (different) values.
 */

  select DISTINCT empid from emp1
  
  
   /*SQL AND, OR and NOT Operators*/
   
   
   select empid,empname from emp1 where empname='azar' OR salary>=20000
   
   
   select * from emp1 order by  salary DESC
   
   
     select * from emp1 order by  salary ASC,empid
     
     
   select address from emp1 where address IS NOT NULL
   
   
   select * from emp1
   
   update emp1 set address='sss' where empid=105
   
   
   DELETE FROM emp1 WHERE empid=105
   
   select MAX(salary) from emp1
   
      select MIN(salary) from emp1
      
         select COUNT(salary) from emp1
         
            select SUM(salary) from emp1
            
 /* 13/3/2018 */
 
  /*SQL LIKE Operator
  
  The LIKE operator is used in a WHERE clause to search for a specified pattern in a column.

There are two wildcards used in conjunction with the LIKE operator:

% - The percent sign represents zero, one, or multiple characters
_ - The underscore represents a single character      


LIKE Operator	Description
WHERE CustomerName LIKE 'a%'	Finds any values that starts with "a"
WHERE CustomerName LIKE '%a'	Finds any values that ends with "a"
WHERE CustomerName LIKE '%or%'	Finds any values that have "or" in any position
WHERE CustomerName LIKE '_r%'	Finds any values that have "r" in the second position
WHERE CustomerName LIKE 'a_%_%'	Finds any values that starts with "a" and are at least 3 characters in length
WHERE ContactName LIKE 'a%o'	Finds any values that starts with "a" and ends with "o"


*/     

select * from emp1


select * from emp1 where empname like '%k'

select * from emp1

select * from emp1 where salary like '%or%'
update emp1 set empname='azar' where empid=101

select * from emp1 where empname like '%or%'
select * from emp1 where empname like 'a_%_%_%'


/*SQL IN Operator*/

/*The IN operator allows you to specify multiple values in a WHERE clause.

The IN operator is a shorthand for multiple OR conditions.*/

select * from emp1

select * from emp1 where empname NOT IN('mohan','azar')

select * from emp1 where salary  IN(20000)

select * from emp1 where empname IN('mohan','azar')

/*SQL BETWEEN Operator*/

/*The SQL BETWEEN Operator
The BETWEEN operator selects values within a given range. The values can be numbers, text, or dates.*/


select * from emp1 where empid between 102 and 103

select * from emp1 where empid not between 102 and 103

select * from emp1 where empid between 102 and 103

select * from emp1
where (empid between 101 and 104)
AND  salary NOT IN (20000)

/*SQL Aliases
SQL aliases are used to give a table, or a column in a table, a temporary name.*/

select empname as emp from emp1

/*SQL JOIN
A JOIN clause is used to combine rows from two or more tables, based on a related column between them.

Different Types of SQL JOINs
Here are the different types of the JOINs in SQL:

(INNER) JOIN: Returns records that have matching values in both tables
LEFT (OUTER) JOIN: Return all records from the left table, and the matched records from the right table
RIGHT (OUTER) JOIN: Return all records from the right table, and the matched records from the left table
FULL (OUTER) JOIN: Return all records when there is a match in either left or right table

*/

select * from emp1

select * from dep

create table dep(depid varchar(50),depname varchar(50),empemail varchar(50))

insert into dep values(201,'developer','admin1@gmail.com')

insert into dep values(202,'testing','admin2@gmail.com')

insert into dep values(203,'document','admin3@gmail.com')

insert into dep values(204,'developer','admin4@gmail.com')

insert into dep values(205,'testing','admin5@gmail.com')



select empname from emp1 union all

select depname from dep 

/*

The SQL GROUP BY Statement
The GROUP BY statement is often used with aggregate functions (COUNT, MAX, MIN, SUM, AVG) to group the result-set by one or more columns.*/




/*The SQL HAVING Clause
The HAVING clause was added to SQL because the WHERE keyword could not be used with aggregate functions.*/