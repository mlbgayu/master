use krrproject

select * from emp

select * from Persons

select e.empname,e.empid,br.salary from emp e cross apply(select * from Persons p where e.empname=p.FirstName)br