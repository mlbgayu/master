use AdventureWorks

CREATE VIEW HumanResources.vwEmployeeDepData WITH 	SCHEMABINDING
AS
SELECT e.EmployeeID, MaritalStatus, DepartmentID
FROM HumanResources.Employee e JOIN 	HumanResources.EmployeeDepartmentHistory d
ON e.EmployeeID = d.EmployeeID

CREATE VIEW HumanResources.vwEmployeeDepData11 WITH 	SCHEMABINDING
AS
SELECT e.EmployeeID, MaritalStatus, DepartmentID
FROM HumanResources.Employee e JOIN 	HumanResources.EmployeeDepartmentHistory d
ON e.EmployeeID = d.EmployeeID

select * from HumanResources.vwEmployeeDepData

select * from HumanResources.vwEmployeeDepData1




CREATE UNIQUE CLUSTERED INDEX 	idx_vwEmployeeDepData
ON HumanResources.vwEmployeeDepData1 (EmployeeID, 	DepartmentID)


select * from HumanResources.vwEmployeeDepData1


CREATE UNIQUE CLUSTERED INDEX 	idx_vwEmployeeDepData
ON HumanResources.vwEmployeeDepData (EmployeeID, 	DepartmentID)


ALTER VIEW HumanResources.vwEmployeeDepData WITH 	SCHEMABINDING
		AS 
		SELECT e.EmployeeID, MaritalStatus, DepartmentID
		FROM HumanResources.Employee e JOIN 	HumanResources.EmployeeDepartmentHistory d
		ON e.EmployeeID = d.EmployeeID


