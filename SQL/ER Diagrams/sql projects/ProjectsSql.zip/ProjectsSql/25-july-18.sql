use pgpthirdbatch

select * from project1


select MIN(salary) from project1

select MAX(salary) from project1

select Count(salary) from project1


select COUNT(salary) as counts from 
project1 where salary>10000 group by username


create table emp1(empid int,empname varchar(40),email varchar(40),salary int)

create table dep1(depid int,depname varchar(40),dephead varchar(50))

insert into emp1 values(101,'azar','azar@gmail.com',20000)
insert into emp1 values(102,'mohan','mohan@gmail.com',20000)
insert into emp1 values(103,'raja','raja@gmail.com',10000)

insert into dep1 values(201,'d-1','h-1')

insert into dep1 values(202,'d-2','h-1')
insert into dep1 values(203,'d-1','h-1')
insert into dep1 values(,'d-1','h-1')

select * from emp1

select * from dep1

select a.empname,a.salary,b.depname,b.dephead from emp1 a inner join dep1 b on a.empid=b.depid

select empname,salary,depname,dephead from emp1 left outer join dep1 on empid=depid

select empname,salary,depname,dephead from emp1 right outer join dep1 on empid=depid

select empname,salary,depname,dephead from emp1 full outer join dep1 on empid=depid


SELECT A.empname AS CustomerName1, B.depname AS CustomerName2
FROM emp1 A, dep1 B
WHERE A.empid != B.depid
