use AdventureWorks

select * from HumanResources.Employee

select EmployeeID,Title as dummy from HumanResources.Employee

SELECT 'Department Number'= DepartmentID,'Department Name'= Name FROM HumanResources.Department 

SELECT EmployeeID, Rate, 
Per_Day_Rate = 12 * Rate 
FROM HumanResources.EmployeePayHistory

select ContactID,MaritalStatus from HumanResources.Employee where MaritalStatus='M'

