

create database krrproject

use krrproject

create table emp(empid varchar(50),empname varchar(50),salary integer)

select * from emp

select empid from emp

insert into emp values(101,'azar',10000)

insert into emp values(102,'mohan',10000)

insert into emp values(103,'sheik',20000)

select empid,empname from emp

use krrproject

select * from emp


alter table emp add email varchar(50)


update emp set email='azar@gmail.com' where salary<=10000

update emp set email='mohan@gmail.com' where salary>=20000


CREATE TABLE Persons (
    ID int IDENTITY(1,5) PRIMARY KEY,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255),
    Age int
);

insert into Persons values('azar','mohamed',30)
insert into Persons values('azar','mohamed',30)

insert into Persons values('azar','ss')

alter table Persons add salary int 

select * from Persons

use krrproject

select * from emp

select empname,salary from emp where empid=101

select * from emp where salary<=10000

select * from emp where email='azar@gmail.com'

select distinct email from emp 

select * from emp

insert into emp values(104,'azar',20000,'mohan@gmail.com')

select * from emp where empname='azar' AND empname='azar'


select * from emp where empname='azar' OR empname='dd'

select * from emp where NOT empname='azar' 

select * from emp order by empname ASC
select * from emp order by empname DESC

update emp set empname='sss' where empid=104

select top 2 * from emp 

select * from emp where salary<=10000



select MIN(salary) from emp

select MAX(salary) from emp

select COUNT(salary) from emp

select AVG(salary) from emp

select SUM(salary) as foo from emp


select * from emp where empname LIKE '%a%'

select * from emp where empname NOT LIKE '%a%'