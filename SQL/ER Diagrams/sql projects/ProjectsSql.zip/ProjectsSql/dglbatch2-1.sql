create database dglproject

use dglproject

create table employee(empid int,empname varchar(50),salary int)

select * from employee

insert into employee values(101,'azar',20000)

insert into employee values(102,'a1',10000)
insert into employee values(103,'a2',10000)
insert into employee values(104,'a3',20000)


select empid,empname from employee

select empid,empname,salary from employee where salary<=10000

alter table employee add age int

select * from employee


update employee set age=25 where salary>=20000

update employee set age=21 where empname='a1'