

use AdventureWorks


 create view sample_view WITH SCHEMABINDING 
 
 as 
 
 select depid from dep

create table dep(depid int,depname varchar(50),salary int)


insert into dep values(101,'ug',20000)

insert into dep values(102,'pg',30000)


select * from dep


create view img_table AS

select depid,depname from dep 

where depid=101



select * from img_table


<!-- Replace Already created view Name to create new Name -->

create or replace view img_table

AS

select depid,depname from dep 

where depid=101



alter view img_table AS 

select depid,depname from dep where depid=102


select * from img_table

select SUM(salary),empid from dep


<!-- sp_rename old_viewname, new_viewname-->


sp_rename img_table,img_tableniit


select * from img_tableniit

drop view img_table




