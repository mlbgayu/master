use krrproject

select * from emp

select * from Persons



update emp set email='sheik@gmail.com' where salary<=10000


select * from emp where empname=(select empname from emp where email='azar@gmail.com')

select * from emp where empname in(select empname from emp where email='azar@gmail.com')

select * from emp where salary>=(select MAX(salary) from emp where email='sheik@gmail.com')