

create database pgpthirdbatch

use pgpthirdbatch

create table  project1(username varchar(40),email varchar(50),
mobile varchar(50),salary int)


select * from project1


select username,email from project1


insert into project1 values('azar1','azar1@gmail.com',9843095933,10000)

<!-- july 23th-18 -->

use pgpthirdbatch

select * from project1

select username,salary*2 as salaryupdated from project1 where username='mohan'

select username,mobile,salary from project1 where email='azar@gmail.com'

select username,email,salary from project1 where username='azar' AND email='azar@gmail.com'




select username,email,salary from project1 where username='azar' OR email='azar3@gmail.com'




select username,email,salary from project1 where NOT username='azar5' 



insert into project1 values('sheik','ss@gmail.com',9843095932,1000)

insert into project1 values('raja','raja@gmail.com',9843095934,1000)

insert into project1 values('raja1','raja@gmail.com',9843095934,1000)

select * from project1

select * from project1 where salary NOT Between 500 AND 11000

select * from project1 where salary  Between 500 AND 11000

select * from project1 where salary in(1000)

select * from project1 where salary in(1000,10000)

select * from project1 where email in('azar@gmail.com')

select * from project1 where email not in('azar@gmail.com')

/* 

LIKE Operator	Description
WHERE CustomerName LIKE 'a%'	Finds any values that start with "a"
WHERE CustomerName LIKE '%a'	Finds any values that end with "a"
WHERE CustomerName LIKE '%or%'	Finds any values that have "or" in any position
WHERE CustomerName LIKE '_r%'	Finds any values that have "r" in the second position
WHERE CustomerName LIKE 'a_%_%'	Finds any values that start with "a" and are at least 3 characters in length
WHERE ContactName LIKE 'a%o'	Finds any values that start with "a" and ends with "o"
*/

select *from project1 where username like'_o%'

select * from project1 where username like'%za%'


CREATE TABLE Employees1 (
    ID int NOT NULL,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255) NOT NULL,
    Age int
);

insert into  Employees1 values(101,'','azar',23)

insert into  Employees1 values(102,'mohan','azar',24)

select * from Employees1 where LastName  IS NOT NULL

select * from Employees1

select * from project1 order by salary Desc

<!-- july 24th-18 -->

use pgpthirdbatch

select * from project1

insert into project1 values('azar','azar@gmail.com',9843095933,10000)

select username=LEFT(username,5) from project1


select distinct *  from project1 

truncate table Employees1

select * from Employees1

SELECT host_name() AS 'HostName'

SELECT suser_sid ('sa') AS SID

SELECT user_id ('LENOVO') AS USERID


SELECT db_id('pgpthirdbatch') AS DatabaseID

SELECT db_name(10) AS DatabaseName


SELECT object_id ('pgpthirdbatch.project1') AS ObjectID


