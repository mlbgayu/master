set SHOWPLAN_ALL ON

select * from HumanResources.Employee

SET SHOWPLAN_ALL OFF

SET SHOWPLAN_XML ON

select * from HumanResources.Employee

SET SHOWPLAN_XML OFF

Select * from DatabaseLog

create index index_s on DatabaseLog(DatabaseLogID)

select * from DatabaseLog where DatabaseLogID=1249

