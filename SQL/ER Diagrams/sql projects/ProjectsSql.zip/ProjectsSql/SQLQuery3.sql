create database TestProject

use TestProject

create table validate(uname varchar(40),pass varchar(40))

select * from validate

