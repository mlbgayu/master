

use DglSqlBatch

create table p1(pid varchar(50),pname varchar(50),quty varchar(50))

create table p2(pid varchar(50),pname varchar(50),price varchar(50))


insert into p1 values(401,'xx',2)
insert into p1 values(402,'yy',3)
insert into p1 values(403,'xy',4)
insert into p1 values(405,'yx',10)
insert into p1 values(407,'yx',10)


insert into p2 values(401,'xx',100)
insert into p2 values(402,'yy',200)
insert into p2 values(403,'xy',100)
insert into p2 values(404,'yx',100)

select * from p1

select * from p2

select p1.pname,p2.price,p1.pid,p2.pid from p1 INNER JOIN p2 on p1.pid=p2.pid

select p1.pname,p2.price,p1.pid,p2.pid from p1 LEFT JOIN p2 on p1.pid=p2.pid

select p1.pname,p2.price,p1.pid,p2.pid from p1 RIGHT JOIN p2 on p1.pid=p2.pid

select p1.pname,p2.price,p1.pid,p2.pid from p1 FULL JOIN p2 on p1.pid=p2.pid

select d1.pname,d2.price,d1.pid,d2.pid from p1 d1,p2 d2 where  d1.pid=d2.pid

select d1.pname,d2.price,d1.pid,d2.pid from p1 d1,p2 d2 where  d1.pid<>d2.pid