use AdventureWorks


<!--Manage result sets
 -->
SELECT d.Customer_name, d.Acc_num, br.Loan_num 
		FROM Depositor d CROSS APPLY 
(SELECT * FROM Borrower b WHERE d.Customer_name = 	b.Customer_name) br

<!--Working with Temporary Result Sets  -->
   WITH RateCTE(Rate)
	   AS
	   (
	   SELECT TOP 10 Rate = Rate FROM
	   HumanResources.EmployeePayHistory
	   )
	   SELECT Rate, Max_Rate = (SELECT max(Rate) FROM 
	   RateCTE) FROM RateCTE


WITH List_CTE(i)
	   AS
	   (
	   SELECT i = CONVERT(varchar(8000),'Welcome')
	   UNION ALL
	   SELECT i + 'A' FROM List_CTE WHERE LEN(i) < 10
	   )
	   SELECT i FROM List_CTE
	   ORDER BY i
