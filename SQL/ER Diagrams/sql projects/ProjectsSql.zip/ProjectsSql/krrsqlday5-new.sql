use AdventureWorks


use krrproject

select * from emp

select * from Persons



SELECT salary FROM emp
	  UNION 
SELECT salary FROM Persons

SELECT salary FROM emp
	  EXCEPT 
SELECT salary FROM Persons

SELECT salary FROM emp
	 INTERSECT 
SELECT salary FROM Persons

select * from HumanResources.EmployeePayHistory

      WITH RateCTE(Rate)
	   AS
	   (
	   SELECT TOP 10 Rate = Rate FROM
	   HumanResources.EmployeePayHistory
	   )
	   SELECT Rate, Max_Rate = (SELECT max(Rate) FROM 
	   RateCTE) FROM RateCTE
	   




select * from  Rate
