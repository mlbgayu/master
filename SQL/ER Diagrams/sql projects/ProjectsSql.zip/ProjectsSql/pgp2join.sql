create database pgp2

use pgp2

create table orders(cusid integer,cusname varchar(50),price varchar(50))

select * from orders

insert into orders values(101,'a1',2000)

insert into orders values(102,'a2',3000)

insert into orders values(103,'a3',2000)
insert into orders values(103,'a3',2000)

create table cus(cusid integer,address varchar(50),age varchar(50))

insert into cus values(101,'krr',29)


insert into cus values(102,'dgl',29)


insert into cus values(101,'krr',24)

select * from cus

SELECT orders.cusname,orders.cusid,cus.cusid,cus.age, orders.price
FROM orders
INNER JOIN cus ON orders.cusid=cus.cusid;

SELECT orders.cusname, cus.age, orders.price
FROM orders
LEFT JOIN cus ON orders.cusid=cus.cusid;

SELECT orders.cusname, cus.age, orders.price
FROM orders
RIGHT JOIN cus ON orders.cusid=cus.cusid;

SELECT orders.cusname, cus.age, orders.price
FROM orders
FULL JOIN cus ON orders.cusid=cus.cusid;

select COUNT(cusid),cusname from orders group by cusname