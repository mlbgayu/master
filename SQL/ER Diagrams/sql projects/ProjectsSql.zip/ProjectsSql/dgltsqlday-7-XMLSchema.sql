use AdventureWorks

CREATE XML SCHEMA COLLECTION EmployeeSchemaCollection as 
'<?xml version="1.0"?> 
<xsd:schema 
        targetNamespace="http://schemas.adventure-works.com/Employees" 
        xmlns="http://schemas.adventure-works.com/Employees" 
        elementFormDefault="qualified" 
        attributeFormDefault="unqualified" 
        xmlns:xsd="http://www.w3.org/2001/XMLSchema" > 
<xsd:element name="EmployeeDetails"> 
<xsd:complexType> 
<xsd:sequence> 
        <xsd:element name="PreviousEmploymentOrg" minOccurs="1" maxOccurs="5"> 
		<xsd:complexType>
		<xsd:simpleContent>
		<xsd:extension base="xsd:string">
		 		<xsd:attribute name="PreviousEmploymentAddress" type="xsd:string" /> 
                <xsd:attribute name="PreviousEmploymentDesig" type="xsd:string" /> 
                <xsd:attribute name="PreviousEmploymentDuration" type="xsd:string" /> 
		</xsd:extension>
		</xsd:simpleContent>
		</xsd:complexType>	
		</xsd:element>
</xsd:sequence> 
</xsd:complexType>      
</xsd:element>
</xsd:schema>'
CREATE TABLE EmployeeHistoryDetails
(
	EmployeeID int,
	EmploymentHistory XML(EmployeeSchemaCollection)
)

INSERT INTO EmployeeHistoryDetails VALUES (1001, 
'<?xml version="1.0"?>
<EmployeeDetails xmlns="http://schemas.adventure-works.com/Employees">
	<PreviousEmploymentOrg 
		PreviousEmploymentAddress = "New Jersey"
		PreviousEmploymentDesig = "Software Developer"
		PreviousEmploymentDuration = "3 Years"> HP </PreviousEmploymentOrg>
	</EmployeeDetails>')

INSERT INTO EmployeeHistoryDetails VALUES (1002, 
'<?xml version="1.0"?>
<EmployeeDetails xmlns="http://schemas.adventure-works.com/Employees">
	<PreviousEmploymentOrg 
		PreviousEmploymentAddress = "New York"
		PreviousEmploymentDesig = "Project Manager"
		PreviousEmploymentDuration = "2 Years"> IBM </PreviousEmploymentOrg>
</EmployeeDetails>')

INSERT INTO EmployeeHistoryDetails VALUES (1003, 
'<?xml version="1.0"?>
<EmployeeDetails xmlns="http://schemas.adventure-works.com/Employees">
	<PreviousEmploymentOrg 
		PreviousEmploymentAddress = "Pallapatti"
		PreviousEmploymentDesig = "Project Manager"
		PreviousEmploymentDuration = "2 Years"> TCS </PreviousEmploymentOrg>
</EmployeeDetails>')





SELECT * FROM EmployeeHistoryDetails



DECLARE @Doc int
DECLARE @XMLDoc nvarchar(1000)
SET @XMLDoc = N'<ROOT>
<Customer CustomerID="JH01" ContactName="John Henriot">
   <Order OrderID="1001" CustomerID="JH01" 
          OrderDate="2006-07-04T00:00:00">
      <OrderDetail ProductID="11" Quantity="12"/>
      <OrderDetail ProductID="22" Quantity="10"/>
   </Order>
</Customer>
<Customer CustomerID="SG01" ContactName="Steve Gonzlez">
   <Order OrderID="1002" CustomerID="SG01" 
          OrderDate="2006-08-16T00:00:00">
      <OrderDetail ProductID="32" Quantity="3"/>
   </Order>
</Customer>
</ROOT>'

EXEC sp_xml_preparedocument @Doc OUTPUT, @XMLDoc

SELECT *
FROM openxml (@Doc, '/ROOT/Customer/Order/OrderDetail',1)
      WITH (CustomerID  varchar(10) '../../@CustomerID',
            ContactName varchar(20) '../../@ContactName',
			OrderID int '../@OrderID',
			OrderDate datetime '../@OrderDate',
			ProdID int '@ProductID',
			Quantity int)

EXEC sp_xml_removedocument @Doc
