
use AdventureWorks


CREATE  INDEX idx_lastname ON Person (lastname)

CREATE INDEX idx_pname ON Person(lastname,firstname);

select * from Person


Select * from DatabaseLog

create table Person(pid int,firstname varchar(50),lastname varchar(50),age int,salary int)


CREATE CLUSTERED INDEX IX_EmployeeID 
ON  HumanResources.Employee(EmployeeID)
WITH FILLFACTOR = 10

select * from Production.ProductModel

CREATE XML INDEX PIdx_ProductModel_CatalogDescription_PATH ON Production.ProductModel (CatalogDescription)
  USING XML INDEX 
	    PXML_ProductModel_CatalogDescription
	    FOR PATH
	    
	CREATE XML INDEX PIdx_ProductModel_CatalogDescription_VALUE ON Production.ProductModel (CatalogDescription)
	USING XML INDEX PXML_ProductModel_CatalogDescription
	FOR VALUE


select * from Person where firstname='azar'

insert into Person values(101,'azar','mohamed',20,30000)

insert into Person values(102,'azar','mohamed',20,40000)