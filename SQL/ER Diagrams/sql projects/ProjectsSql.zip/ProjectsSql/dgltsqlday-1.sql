create database DglSqlBatch

use DglSqlBatch

create table emp(empid integer,empname varchar(40),addres varchar(50),salary varchar(50))

select * from emp

insert into emp values(101,'azar','ppt',20000)

insert into emp values(104,'hhh','ppt',10000)

insert into emp values(103,'shiek','krr',10000)

alter table emp alter column addr varchar(50)

alter table emp add age integer

select * from emp

update  emp set age=29 where salary>=20000


update  emp set age=28 where salary<=10000

select * from emp where age<=28


