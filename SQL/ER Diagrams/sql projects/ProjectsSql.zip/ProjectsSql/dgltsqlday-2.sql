use DglSqlBatch

select * from emp

CREATE TABLE Persons (
    ID int NOT NULL,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255) NOT NULL,
    Age int
);

insert into Persons values(100,'','',23)

select * from Persons

alter table Persons add salary varchar(60)

select * from emp


CREATE TABLE Persons1 (
    ID int IDENTITY(1,2) PRIMARY KEY,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255),
    Age int
);

insert into Persons1 values('azar','mohan',23)

insert into Persons1 values('azar1','mohan1',23)

select * from Persons1