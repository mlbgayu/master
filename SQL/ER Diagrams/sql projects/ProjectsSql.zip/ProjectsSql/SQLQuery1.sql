create database sample

use sample


create table ulogin(uname varchar(20),pass varchar(30))

insert into ulogin values('admin','admin')

select * from ulogin

create table utable(uname varchar(40),gen varchar(40),check1 varchar(40),check2 varchar(40),dept varchar(40))

select * from utable