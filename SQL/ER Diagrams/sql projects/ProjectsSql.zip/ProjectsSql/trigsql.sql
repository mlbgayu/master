
create database pgpthirdbatch
use pgpthirdbatch
---triggers---
create table sales (csalesid int, vproductname varchar(40),quantity int)
create table stock (csalesid int, vproductname varchar(40),price int,quantity int)
insert into stock values (001,'keyboard',150,100)
insert into stock values (002,'mointor',2500,80)
insert into stock values (003,'mouse',120,100)
insert into stock values (004,'cpu',4500,90)




create trigger salesTrg
on sales
for insert 
as 
declare @sid int,@qty int
select @sid=csalesid,@qty=quantity from sales
update stock 
set quantity=quantity-@qty where csalesid=@sid



alter trigger salesTrg
on sales
for insert 
as 
declare @sid int,@qty int
select @sid=csalesid,@qty=quantity from sales
update stock 
set quantity=quantity-@qty where csalesid=@sid




select * from sales
select * from stock

insert into sales values (001,'keyboard',100)

insert into sales values (002,'mointor',10)