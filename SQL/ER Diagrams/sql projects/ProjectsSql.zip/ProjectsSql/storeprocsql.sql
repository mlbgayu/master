use pgpthirdbatch

select * from employee


create table employee(empid varchar(50),empname varchar(50),salary varchar(50))


insert into employee values(101,'admin',20000)

insert into employee values(102,'admin1',20000)


create proc pemp4 @id int,@name varchar(100) output as
begin
 select @name=empname from employee where empid=@id;
end 

begin 
  
  declare @empname varchar(100);
  
  execute pemp4 101,@empname output;
  
 
  print @empname;
  
 end
  
  
execute pemp4 101
  
