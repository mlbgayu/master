use krrproject

select * from emp

select * from Persons

update Persons set salary=10000 where Age>=30

update Persons set FirstName='sheik' where ID=11


select emp.empname,Persons.FirstName,Persons.ID from 
emp FULL JOIN Persons on emp.salary=Persons.salary

select * from emp

select * from Persons

