create database college
use college
create table dep1(depid varchar(50),studname varchar(50),age integer,salary integer)
select * from dep1

insert into dep1 values(101,'azar',28,10000)

insert into dep1 values(102,'mohan',20,15000)
insert into dep1 values(103,'raja',25,12000)
insert into dep1 values(104,'sheik',22,18000)
insert into dep1 values(105,'david',30,20000)

select *from dep1
create table dep2(depid varchar(50),studname varchar(50),address varchar(50),dob date)
select * from dep2

insert into dep2 values(106,'azar','aaa','2000-01-02')

insert into dep2 values(107,'mohan','bbb','2000-02-03')
insert into dep2 values(108,'raja','ccc','2000-03-04')
insert into dep2 values(109,'sheik','ddd','2000-04-05')
insert into dep2 values(110,'david','eee','2000-05-06')

select *from dep2

select dep from dep1  left join dep2 on dep1.depid=dep2.depid
select *from dep1
delete from dep2 where depid=106
select *from dep2
delete from dep2 where depid=107
delete from dep2 where depid=107
delete from dep2 where depid=108
delete from dep2 where depid=109
delete from dep2 where depid=110
select *from dep2
select *from dep1  fully outer join dep2 on dep1.depid=dep1.depid
select *from dep1





