use krrproject


select * from emp

begin transaction
  save transaction s1
  delete from emp where empid=102
  select * from emp
  
  
  rollback transaction s1
  
  
  save transaction s2
  
  delete from emp where empid=101
  
  rollback transaction s2
  
  
  
  commit
  
  rollback
  
  select * from emp