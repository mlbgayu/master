use AdventureWorks

CREATE PROCEDURE prcDept1
AS
BEGIN
SELECT Name FROM
HumanResources.Department where DepartmentID>10
END

exec prcDept1

ALTER PROCEDURE prcDept1
	AS
	BEGIN
	SELECT DepartmentID, Name FROM HumanResources.Department
	END


DROP PROCEDURE prcDept
exec prcDept

select * from HumanResources.Department


CREATE PROC prcListEmployee @title char(50)
		AS 
		BEGIN
			PRINT 'List of Employees'
			SELECT EmployeeID, LoginID, Title
			FROM HumanResources.Employee 
			WHERE Title = @title
		END


EXECUTE prcListEmployee 'Tool Designer'
