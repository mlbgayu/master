use AdventureWorks

select AVG(VacationHours) from HumanResources.Employee where Title='Marketing Assistant'

SELECT EmployeeId FROM HumanResources.Employee 
	WHERE VacationHours >(SELECT AVG(VacationHours) FROM HumanResources.Employee 
	WHERE Title = 'Marketing Assistant')
	
	select * from HumanResources.Employee
	
	SELECT DepartmentID FROM HumanResources.EmployeeDepartmentHistory 
	WHERE EmployeeID = 
	(SELECT EmployeeID FROM HumanResources.Employee
	WHERE ContactID =
	(SELECT ContactID FROM Person.Contact WHERE EmailAddress = 'taylor0@adventure-works.com')
	)

	SELECT * FROM EmployeeDetails e 
	WHERE Salary = (SELECT max(Salary) 
	FROM EmployeeDetails WHERE DeptNo = e.DeptNo)


