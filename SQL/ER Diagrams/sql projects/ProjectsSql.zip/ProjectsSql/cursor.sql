begin
   declare @empid int;
   declare @name varchar(40);
   declare @sal numeric(30);
   declare empcur cursor for
   select empid,empname,salary from employee where empid=101;
   open empcur;
   fetch next from empcur into @empid,@name,@sal;
   while @@FETCH_STATUS=0
   begin
   if @sal>2000
   begin
   set  @sal=@sal+20;
   end
   else
   begin
  set @sal=@sal+50;
   end
   update employee set salary=@sal where empid=@empid
   print @name+'new earns'+cast (@sal as varchar);
   print @name
   print @sal
   fetch next from empcur into @empid,@name,@sal;
   
   end
   close empcur;
  
end
   