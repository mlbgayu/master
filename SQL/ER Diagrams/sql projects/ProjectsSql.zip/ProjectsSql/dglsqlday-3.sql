select GETDATE()

SELECT datename(year,convert(datetime,'2018-11-06'))

SELECT ceiling(14)

SELECT exp(4.5)

select round (100.56,-3)

create table rankfunction(empid varchar(50),rate int,salary int)

insert into rankfunction values(101,125.5,20000)

insert into rankfunction values(102,155.5,10000)


insert into rankfunction values(103,120.5,10000)

select * from rankfunction

select empid,rate,salary, ROW_NUMBER() over(order by salary desc)as rank from rankfunction

select empid,rate,salary, Rank() over(order by salary desc)as rank from rankfunction


SELECT * FROM rankfunction
WHERE salary <=10000

SELECT TOP 50 PERCENT * FROM rankfunction

select MAX(salary) as xyz from rankfunction


select MIN(salary) as xyz from rankfunction

select count(salary) as xyz from rankfunction

select sum(salary) as xyz from rankfunction


select avg(salary) as xyz from rankfunction






