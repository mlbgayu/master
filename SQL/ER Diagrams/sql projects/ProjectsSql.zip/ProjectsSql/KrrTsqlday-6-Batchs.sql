use AdventureWorks

--Example 1
DECLARE @Rate int
SELECT @Rate = max(Rate)
FROM HumanResources.EmployeePayHistory	

print @Rate

GO
--Example 2
DECLARE @Rate money
SELECT @Rate = Rate FROM HumanResources.EmployeePayHistory
WHERE EmployeeID = 23


IF @Rate < 15
BEGIN
	PRINT 'Review required'
END	
	
ELSE
BEGIN
PRINT 'Review not required'
     	PRINT 'your rate ='
     	PRINT @Rate
END
GO
--Example 3

SELECT EmployeeID, 'Marital Status' =
CASE MaritalStatus
		WHEN 'M' THEN 'Married'
		WHEN 'S' THEN 'Single'
		ELSE 'Not specified'
END
FROM HumanResources.Employee

--print @MaritalStatus

GO

select * from HumanResources.Employee

--Example 4

WHILE (SELECT AVG(Rate)+1 from HumanResources.EmployeePayHistory) < 20
BEGIN
	UPDATE HumanResources.EmployeePayHistory
	SET Rate = Rate + 1
	FROM HumanResources.EmployeePayHistory
	IF (Select MAX(Rate)+1 from HumanResources.EmployeePayHistory) > 127
		BREAK
	ELSE
		CONTINUE
		
END
GO