create database sample
use sample
create table ulogin(uname varchar(10),pass varchar(10))
insert into ulogin values('admin','admin')
select * from ulogin