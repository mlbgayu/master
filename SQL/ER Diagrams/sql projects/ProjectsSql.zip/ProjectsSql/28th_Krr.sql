use AdventureWorks

DECLARE @Rate int
SELECT @Rate = max(Rate)
FROM HumanResources.EmployeePayHistory
print @Rate
GO

DECLARE @Rate money
SELECT @Rate = Rate FROM HumanResources.EmployeePayHistory
WHERE EmployeeID = 23
IF @Rate < 5
BEGIN
	PRINT 'Review required'
END	
ELSE
BEGIN
PRINT 'Review not required'
     	PRINT 'your rate ='
     	PRINT @Rate
END
GO


SELECT  Rate FROM HumanResources.EmployeePayHistory
WHERE EmployeeID = 23

SELECT EmployeeID, 'Marital Status' =
CASE MaritalStatus
		WHEN 'M' THEN 'Married'
		WHEN 'S' THEN 'Single'
		ELSE 'Not specified'
END
FROM HumanResources.Employee
GO

select EmployeeID,MaritalStatus from HumanResources.Employee


WHILE (SELECT AVG(Rate)+1 from HumanResources.EmployeePayHistory) < 20
BEGIN
	UPDATE HumanResources.EmployeePayHistory
	SET Rate = Rate + 1
	FROM HumanResources.EmployeePayHistory
	IF (Select MAX(Rate)+1 from HumanResources.EmployeePayHistory) > 127
		BREAK
	ELSE
		CONTINUE
END


select * from Person



BEGIN TRY
   -- This will generate an error, as EmployeeID is an IDENTITY column
   -- Ergo, we can't specify a value for this column...
   INSERT INTO HumanResources.Employee(EmployeeID, Title)
   VALUES(101, 'Tool Designer')
END TRY
BEGIN CATCH
SELECT 'There was an error! ' + ERROR_MESSAGE() AS   ErrorMessage, 
    ERROR_LINE()         AS ErrorLine,
    ERROR_NUMBER()       AS ErrorNumber,
    ERROR_PROCEDURE()    AS ErrorProcedure,
    ERROR_SEVERITY()     AS ErrorSeverity,
    ERROR_STATE()        AS ErrorState
END CATCH

-----------------------------------------------------------------------------------
BEGIN TRY
   -- This will generate an error, as EmployeeID is an IDENTITY column
   -- Ergo, we can't specify a value for this column...
   INSERT INTO Person(firstname,lastname,age,salary)
   VALUES(103, 'Designer',23,20000)
END TRY
BEGIN CATCH
SELECT 'There was an error! ' + ERROR_MESSAGE() AS   ErrorMessage, 
    ERROR_LINE()         AS ErrorLine,
    ERROR_NUMBER()       AS ErrorNumber,
    ERROR_PROCEDURE()    AS ErrorProcedure,
    ERROR_SEVERITY()     AS ErrorSeverity,
    ERROR_STATE()        AS ErrorState
END CATCH
--------------------------------------------------------------------
CREATE PROCEDURE prcDept
		AS
		BEGIN
   	  SELECT Name FROM HumanResources.Department
		END

exec prcDept



ALTER PROCEDURE prcDept
	AS
	BEGIN
	SELECT DepartmentID, Name FROM HumanResources.Department
	END

exec prcDept

DROP PROCEDURE prcDept


CREATE PROC prcListEmployee @title char(50)
		AS 
		BEGIN
			PRINT 'List of Employees'
			SELECT EmployeeID, LoginID, Title
			FROM HumanResources.Employee 
			WHERE Title = @title
		END

exec prcListEmployee 'Tool Designer'


CREATE TABLE BRANCH(Branch_ID int Primary Key,Branch_Name varchar(20))


 CREATE TYPE NType AS TABLE (Br_ID int, Br_Name 
	 Varchar(20))
	 
--select * from NType


drop procedure Table_PROC

CREATE procedure Table_PROC 
@ParamTable NType READONLY
	    AS
	    INSERT INTO Branch(Branch_ID,Branch_Name)
	    SELECT * FROM @ParamTable


DECLARE @TableTest AS NType
	    INSERT INTO @TableTest (Br_ID, Br_Name) VALUES 
	    (1,'Admin'), (2,'User')
	    EXECUTE Table_PROC @TableTest
	       
SELECT * FROM BRANCH




select * from @ParamTable


CREATE PROCEDURE prcGetEmployeeDetail @EmpId int, @DepId int OUTPUT, @DepName char(50) OUTPUT, @ShiftId int OUTPUT
AS
BEGIN
IF EXISTS(SELECT * FROM HumanResources.Employee WHERE EmployeeID = @EmpId)
	BEGIN
		SELECT @DepId = d.DepartmentID, @DepName = Name, 
@ShiftId = ShiftID
FROM HumanResources.Department d JOIN HumanResources.EmployeeDepartmentHistory h
		ON d.DepartmentID = h.DepartmentID
		WHERE EmployeeID = @EmpId
		RETURN 0
	END
	ELSE
		RETURN 1
END


